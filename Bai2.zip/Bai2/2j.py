import numpy as np
import scipy.stats as stats

# Cài đặt các thông số cho mẫu dữ liệu
n = 20
k = 200
min_value = 100
max_value = 3600
mean = (min_value + max_value) / 2
std = (max_value - min_value) / 6

# Sinh ra mẫu dữ liệu tuân theo phân bố chuẩn
sample = np.random.normal(mean, std, n)
sample = np.round(sample, 0)

# In ra mẫu dữ liệu
print("Mẫu dữ liệu tuân theo phân bố chuẩn là: ")
print(sample)

# Kiểm tra phân bố chuẩn của mẫu dữ liệu
stat, p_value = stats.shapiro(sample)
alpha = 0.05
if p_value < alpha:
    print("Mẫu dữ liệu không tuân theo phân bố chuẩn")
else:
    print("Mẫu dữ liệu tuân theo phân bố chuẩn")
