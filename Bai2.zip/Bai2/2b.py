import json
import random

def update_config_with_randomness(file_path, randomness_enabled):
    with open(file_path, 'r') as file:
        config = json.load(file)
    
    # Cập nhật cấu hình với tùy chọn "randomness"
    config['randomness'] = {
        "description": "The option for establishing new random configuration or load from the file",
        "value": randomness_enabled
    }
    
    # Nếu tùy chọn "randomness" được bật, tạo ra cấu hình ngẫu nhiên mới
    if randomness_enabled == 1:
        # Tạo ra các giá trị cấu hình ngẫu nhiên mới
        # Ví dụ: config['someConfigValue'] = random.randint(0, 100)
        pass  # Thay thế 'pass' bằng mã tạo cấu hình ngẫu nhiên của bạn
    
    # Ghi lại file cấu hình đã cập nhật
    with open(file_path, 'w') as file:
        json.dump(config, file, indent=4)

# Đường dẫn tới file input.json
config_file_path = 'path/to/input.json'
# Bật tùy chọn "randomness" (1 - bật, 0 - tắt)
randomness_enabled = 1
update_config_with_randomness(config_file_path, randomness_enabled)
