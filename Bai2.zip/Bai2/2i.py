import numpy as np
import scipy.stats as stats

# Cài đặt các thông số cho mẫu dữ liệu
n = 43
k = 200
min_value = -1
max_value = 1
mean = (min_value + max_value) / 2
std = (max_value - min_value) / 6

allEvents = []

# Sinh ra mẫu dữ liệu và kiểm tra phân bố chuẩn
for i in range(6):
    sample = np.random.normal(mean, std, n)
    sample = np.round(sample, 1)
    stat, p_value = stats.shapiro(sample)
    
    alpha = 0.05
    if p_value < alpha:
        print("Mẫu dữ liệu không tuân theo phân bố chuẩn")
        exit()
    else:
        allEvents.append(sample)

# Hiệu chỉnh các giá trị để đảm bảo tính nhất quán trong tác động cảm xúc
for i in range(n):
    if allEvents[0][i] < 0:
        for j in range(6):
            allEvents[j][i] = -abs(allEvents[j][i])
    else:
        for j in range(6):
            allEvents[j][i] = abs(allEvents[j][i])

# In ra kết quả
print(allEvents)
