import json

def update_config_for_run_mode(file_path):
    with open(file_path, 'r') as file:
        config = json.load(file)
    
    run_mode = config.get('runMode', {}).get('value', 1)
    
    if run_mode == 3:
        # Loại bỏ các trường không cần thiết khi runMode là 3
        unnecessary_fields = ['noRunPerHallway', 'TDDegree', 'totalCrowdLength', 
                              'headCrowdLength', 'crowdWidth', 'stopAtHallway', 
                              'hallwayLength', 'hallwayWidth']
        for field in unnecessary_fields:
            config.pop(field, None)
    
    # Ghi lại file cấu hình đã cập nhật
    with open(file_path, 'w') as file:
        json.dump(config, file, indent=4)

# Đường dẫn tới file input.json
config_file_path = 'path/to/input.json'
update_config_for_run_mode(config_file_path)
