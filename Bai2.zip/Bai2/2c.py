import json
import numpy as np
import scipy.stats as stats

def add_age_distribution_to_config(config_path, num_of_agents):
    # Đọc file cấu hình
    with open(config_path, 'r') as file:
        config = json.load(file)
    
    # Thêm tùy chọn "ageDistribution" vào cấu hình
    config['ageDistribution'] = {
        "description": "distribution of age in pedestrians",
        "distribution": {
            "normal": {
                "description": "normal distribution",
                "samples": num_of_agents,
                "numberOfValues": 100,
                "minValue": 5,
                "maxValue": 104
            }
        }
    }
    
    # Ghi lại file cấu hình đã cập nhật
    with open(config_path, 'w') as file:
        json.dump(config, file, indent=4)

    # Sinh ra dữ liệu tuân theo phân bố chuẩn
    mean = (config['ageDistribution']['distribution']['normal']['minValue'] +
            config['ageDistribution']['distribution']['normal']['maxValue']) / 2
    std = (config['ageDistribution']['distribution']['normal']['maxValue'] -
           config['ageDistribution']['distribution']['normal']['minValue']) / 6
    sample = np.random.normal(mean, std, num_of_agents)
    sample = np.clip(sample, config['ageDistribution']['distribution']['normal']['minValue'],
                     config['ageDistribution']['distribution']['normal']['maxValue'])
    sample = np.round(sample, 1)
    
    # Kiểm tra xem mẫu dữ liệu có tuân theo phân bố chuẩn không
    stat, p_value = stats.kstest(sample, 'norm', args=(mean, std))
    
    # In ra kết quả kiểm định
    print("Giá trị p_value là:", p_value)
    alpha = 0.05  # Mức ý nghĩa thống kê
    if p_value < alpha:
        print("Mẫu dữ liệu không tuân theo phân bố chuẩn")
    else:
        print("Mẫu dữ liệu tuân theo phân bố chuẩn")
        print("Mẫu dữ liệu tuân theo phân bố chuẩn là:", sample)
        print("Giá trị cực tiểu là:", np.min(sample))
        print("Giá trị cực đại là:", np.max(sample))

# Đường dẫn tới file cấu hình
config_file_path = 'path/to/config.json'
# Số lượng người đi bộ (được lấy từ cấu hình)
num_of_agents = 50  # Giả sử giá trị này được lấy từ cấu hình
add_age_distribution_to_config(config_file_path, num_of_agents)
