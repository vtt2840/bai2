import json
import numpy as np
from scipy import stats

# Đường dẫn tới file cấu hình
config_file_path = 'path/to/config.json'

# Đọc file cấu hình
with open(config_file_path, 'r') as file:
    config = json.load(file)

# Số lượng người đi bộ (được lấy từ cấu hình)
num_of_agents = config.get('numOfAgents', 50)  # Giả sử giá trị này được lấy từ cấu hình

# Cập nhật cấu hình với tùy chọn "walkability"
config['walkability'] = {
    "description": "velocity distribution of pedestrians",
    "distribution": {
        "noDisabilityNoOvertaking": {
            "description": "Percentage of agents (No disability, without overtaking behavior)",
            "velocity": 1.24
        },
        "noDisabilityOvertaking": {
            "description": "Percentage of agents (No disability, with overtaking behavior)",
            "velocity": 2.48
        },
        "crutches": {
            "description": "Percentage of agents (Walking with crutches)",
            "velocity": 0.94
        },
        "sticks": {
            "description": "Percentage of agents (Walking with sticks)",
            "velocity": 0.81
        },
        "wheelchairs": {
            "description": "Percentage of agents (Wheelchairs)",
            "velocity": 0.69
        },
        "blind": {
            "description": "Percentage of agents (The blind)",
            "velocity": 0.52
        },
        "normal": {
            "description": "normal distribution",
            "samples": 6,
            "sumOfValues": num_of_agents,
            "lowerBound": 0,
            "upperBound": 10000
        }
    }
}

# Ghi lại file cấu hình đã cập nhật
with open(config_file_path, 'w') as file:
    json.dump(config, file, indent=4)

# Sinh giá trị ngẫu nhiên cho 6 nhóm
num_samples = 6
total_value = num_of_agents
lower_bound = 0
upper_bound = 10000

# Tính giá trị trung bình và độ lệch chuẩn
mean = total_value / num_samples
std_dev = (mean - lower_bound) / 3

# Tạo ra các mẫu ngẫu nhiên tuân theo phân phối chuẩn
samples = np.random.normal(mean, std_dev, num_samples)
samples = samples * total_value / np.sum(samples)
samples = np.clip(samples, lower_bound, upper_bound)
samples = np.round(samples, 0)

# Kiểm định Shapiro-Wilk
stat, p = stats.shapiro(samples)
alpha = 0.05
if p < alpha:
    print("Theo kiểm định Shapiro-Wilk, các mẫu không tuân theo phân phối chuẩn")
else:
    print("Theo kiểm định Shapiro-Wilk, các mẫu có thể tuân theo phân phối chuẩn")

# In ra các giá trị ngẫu nhiên đã sinh ra
print("Các giá trị ngẫu nhiên cho 6 nhóm là:", samples)
print("Tổng các giá trị của mẫu:", np.sum(samples))
