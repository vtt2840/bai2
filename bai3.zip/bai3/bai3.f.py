import numpy as np

# Số lượng người cần tạo
num_people = 1000

# Tạo mẫu ngẫu nhiên cho tuổi và tính cách
age = np.random.randint(11, 100, num_people)  # Tuổi từ 11 đến 99
personality = np.random.rand(num_people)  # Tính cách ngẫu nhiên từ 0 đến 1

# Lọc ra những người có tuổi lớn hơn hoặc bằng 11 và không có tính cách neurotic
filtered_personality = personality[age >= 11]
filtered_age = age[age >= 11]

# Đếm số lượng người
num_filtered_people = len(filtered_personality)

# Tính số người có tính cách neurotic
num_neurotic = np.sum(filtered_personality < 0.5)

# Kiểm tra xem có người nào không thỏa mãn yêu cầu không
if num_neurotic > 0:
    print("Có người không thỏa mãn yêu cầu.")
else:
    print("Không có người nào dưới 11 tuổi lại có tính cách neurotic.")
