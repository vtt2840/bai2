# Tạo một từ điển chứa giá trị cảm xúc ban đầu
initial_emotions = {
    "pleasure": 0.75,
    "surprise": 0.5,
    "anger": -0.2,
    "fear": -0.2,
    "hate": -0.4,
    "sad": -0.4
}

# Tạo một danh sách chứa thông tin về mỗi người (ở đây là danh sách rỗng)
people = []

# Số lượng người
num_people = 100

# Tạo thông tin cho mỗi người
for _ in range(num_people):
    person_info = {
        "emotion": initial_emotions.copy()  # Sao chép giá trị cảm xúc ban đầu để tránh thay đổi đồng thời trong danh sách
    }
    people.append(person_info)

# In ra thông tin của mỗi người
for i, person in enumerate(people, start=1):
    print("Người", i, ":", person)
