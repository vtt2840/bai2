#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <random>
#include <ctime>

// Enum Walkability
enum Walkability {
    noDisability,
    crutches,
    sticks,
    wheelchairs,
    blind
};

// Class Point
class Point {
public:
    double x;
    double y;

    Point(double x, double y) : x(x), y(y) {}
};

// Class Ward
class Ward {
public:
    std::string name;
    Point entrance;
    Point exit;
    std::vector<Point> walls;

    Ward(std::string name, Point entrance, Point exit, std::vector<Point> walls)
        : name(name), entrance(entrance), exit(exit), walls(walls) {}
};

// Class Emotion
class Emotion {
public:
    double pleasure = 0.75;
    double surprise = 0.5;
    double anger = -0.2;
    double fear = -0.2;
    double hate = -0.4;
    double sad = -0.4;
};

// Class Event
class Event {
public:
    double intensity;
    double time;

    Event(double intensity, double time) : intensity(intensity), time(time) {}
};

// Class AGVEvent
class AGVEvent {
    // Định nghĩa lớp AGVEvent
};

// Class Personality
class Personality {
    // Định nghĩa lớp Personality
};

// Class Pedestrian
class Pedestrian {
public:
    int ID;
    Ward start;
    Ward end;
    std::vector<Ward> journey;
    double velocity;
    Personality personality;
    Emotion emotion;
    std::vector<Event> events;
    double walkingTime;
    double distance;
    double age;
    AGVEvent impactOfAGV;
    Point tempPoints;

    Pedestrian(int ID, Ward start, Ward end, std::vector<Ward> journey, double velocity, Personality personality,
               Emotion emotion, std::vector<Event> events, double walkingTime, double distance, double age, AGVEvent impactOfAGV, Point tempPoints)
        : ID(ID), start(start), end(end), journey(journey), velocity(velocity), personality(personality), emotion(emotion), events(events), walkingTime(walkingTime),
          distance(distance), age(age), impactOfAGV(impactOfAGV), tempPoints(tempPoints) {}

    // Hàm sinh sự kiện ngẫu nhiên
    void generateRandomEvents(std::vector<Event>& allEvents, std::vector<double>& allTimeDistances) {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(0, allEvents.size() - 1);

        for (int i = 0; i < 20; ++i) {
            int X = dis(gen);
            Event event(allEvents[X].intensity, allTimeDistances[X]);
            events.push_back(event);
        }
    }
};

// Class Patient
class Patient : public Pedestrian {
public:
    Walkability walkability;

    Patient(int ID, Ward start, Ward end, std::vector<Ward> journey, double velocity, Personality personality,
            Emotion emotion, std::vector<Event> events, double walkingTime, double distance, double age, AGVEvent impactOfAGV, Point tempPoints,
            Walkability walkability)
        : Pedestrian(ID, start, end, journey, velocity, personality, emotion, events, walkingTime, distance, age, impactOfAGV, tempPoints), walkability(walkability) {}
};

// Class Visitor
class Visitor : public Pedestrian {
public:
    Walkability walkability;

    Visitor(int ID, Ward start, Ward end, std::vector<Ward> journey, double velocity, Personality personality,
            Emotion emotion, std::vector<Event> events, double walkingTime, double distance, double age, AGVEvent impactOfAGV, Point tempPoints,
            Walkability walkability)
        : Pedestrian(ID, start, end, journey, velocity, personality, emotion, events, walkingTime, distance, age, impactOfAGV, tempPoints), walkability(walkability) {}
};

// Class Personel
class Personel : public Pedestrian {
public:
    Walkability walkability;

    Personel(int ID, Ward start, Ward end, std::vector<Ward> journey, double velocity, Personality personality,
             Emotion emotion, std::vector<Event> events, double walkingTime, double distance, double age, AGVEvent impactOfAGV, Point tempPoints,
             Walkability walkability)
        : Pedestrian(ID, start, end, journey, velocity, personality, emotion, events, walkingTime, distance, age, impactOfAGV, tempPoints), walkability(walkability) {}
};

int main() {
    // Khởi tạo danh sách sự kiện và khoảng cách thời gian giữa các sự kiện
    std::vector<Event> allEvents; // Đã được khởi tạo từ trước
    std::vector<double> allTimeDistances; // Đã được khởi tạo từ trước

    // Tạo danh sách người đi bộ
    std::vector<Pedestrian> pedestrians;

    // Thêm thông tin cho mỗi người đi bộ
    for (int i = 0; i < 100; ++i) {
        // Khởi tạo thông tin cho mỗi người đi bộ
        // ...

        // Thêm ngẫu nhiên sự kiện cho người đi bộ
        pedestrians[i].generateRandomEvents(allEvents, allTimeDistances);
    }

    // Lưu thông tin của người đi bộ vào file JSON
    std::ofstream outputFile("pedestrians.json");
    if (outputFile.is_open()) {
        for (const auto& person : pedestrians) {
            // Ghi thông tin của mỗi người đi bộ vào file
            // ...
        }
        outputFile.close();
    } else {
        std::cout << "Unable to open file";
    }

    return 0;
}
