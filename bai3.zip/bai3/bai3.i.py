import json
import random
from collections import namedtuple

# Enum Walkability
class Walkability:
    noDisability = 0
    crutches = 1
    sticks = 2
    wheelchairs = 3
    blind = 4

# Class Point
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

# Class Ward
class Ward:
    def __init__(self, name, entrance, exit, walls):
        self.name = name
        self.entrance = entrance
        self.exit = exit
        self.walls = walls

# Class Emotion
class Emotion:
    pleasure = 0.75
    surprise = 0.5
    anger = -0.2
    fear = -0.2
    hate = -0.4
    sad = -0.4

# Class Event
Event = namedtuple('Event', ['intensity', 'time'])

# Class AGVEvent
class AGVEvent:
    pass

# Class Personality
class Personality:
    pass

# Class Pedestrian
class Pedestrian:
    def __init__(self, ID, start, end, journey, velocity, personality, emotion, events, walkingTime, distance, age, impactOfAGV, tempPoints):
        self.ID = ID
        self.start = start
        self.end = end
        self.journey = journey
        self.velocity = velocity
        self.personality = personality
        self.emotion = emotion
        self.events = events
        self.walkingTime = walkingTime
        self.distance = distance
        self.age = age
        self.impactOfAGV = impactOfAGV
        self.tempPoints = tempPoints

    def generate_random_events(self, all_events, all_time_distances):
        for _ in range(20):
            X = random.randint(0, len(all_events) - 1)
            event = Event(all_events[X].intensity, all_time_distances[X])
            self.events.append(event)

# Class Patient
class Patient(Pedestrian):
    def __init__(self, ID, start, end, journey, velocity, personality, emotion, events, walkingTime, distance, age, impactOfAGV, tempPoints, walkability):
        super().__init__(ID, start, end, journey, velocity, personality, emotion, events, walkingTime, distance, age, impactOfAGV, tempPoints)
        self.walkability = walkability

# Class Visitor
class Visitor(Pedestrian):
    def __init__(self, ID, start, end, journey, velocity, personality, emotion, events, walkingTime, distance, age, impactOfAGV, tempPoints, walkability):
        super().__init__(ID, start, end, journey, velocity, personality, emotion, events, walkingTime, distance, age, impactOfAGV, tempPoints)
        self.walkability = walkability

# Class Personel
class Personel(Pedestrian):
    def __init__(self, ID, start, end, journey, velocity, personality, emotion, events, walkingTime, distance, age, impactOfAGV, tempPoints, walkability):
        super().__init__(ID, start, end, journey, velocity, personality, emotion, events, walkingTime, distance, age, impactOfAGV, tempPoints)
        self.walkability = walkability

# Khởi tạo danh sách sự kiện và khoảng cách thời gian giữa các sự kiện
all_events = []  # Đã được khởi tạo từ trước
all_time_distances = []  # Đã được khởi tạo từ trước

# Tạo danh sách người đi bộ
pedestrians = []

# Thêm thông tin cho mỗi người đi bộ
for _ in range(100):
    # Khởi tạo thông tin cho mỗi người đi bộ
    # ...

    # Thêm ngẫu nhiên sự kiện cho người đi bộ
    pedestrian.generate_random_events(all_events, all_time_distances)
    pedestrians.append(pedestrian)

# Lưu thông tin của người đi bộ vào file JSON
with open('pedestrians.json', 'w') as outfile:
    json.dump([vars(p) for p in pedestrians], outfile, indent=4)
