import json

class Pedestrian:
    def __init__(self, type):
        self.type = type

class Patient(Pedestrian):
    def __init__(self):
        super().__init__('Patient')

class Visitor(Pedestrian):
    def __init__(self):
        super().__init__('Visitor')

class Personel(Pedestrian):
    def __init__(self):
        super().__init__('Personel')

# Đọc dữ liệu từ file input.json
with open('input.json') as f:
    data = json.load(f)

# Lấy giá trị của trường numOfAgents từ file input.json
num_of_agents = data['numOfAgents']['value']

# Tạo mảng các đối tượng Pedestrian theo số lượng yêu cầu
pedestrians = []
num_of_personel = 0

# Tính số lượng người không có khuyết tật
num_of_no_disability = num_of_agents * (data['walkability']['distribution']['noDisabilityNoOvertaking']['velocity'] + data['walkability']['distribution']['noDisabilityOvertaking']['velocity'])

for _ in range(num_of_agents):
    # Tùy thuộc vào loại người đi bộ, tạo ra đối tượng tương ứng
    if num_of_personel < num_of_no_disability:
        pedestrians.append(Personel())
        num_of_personel += 1
    elif data['walkability']['distribution']['noDisabilityNoOvertaking']['velocity']:
        pedestrians.append(Patient())
    else:
        pedestrians.append(Visitor())

# Kiểm tra xem số lượng phần tử trong mảng pedestrians có đúng bằng M không
if len(pedestrians) == num_of_agents:
    print("Số lượng người đi bộ đã tạo đúng bằng giá trị của trường numOfAgents")
else:
    print("Số lượng người đi bộ đã tạo không đúng bằng giá trị của trường numOfAgents")

# Kiểm tra xem có đối tượng nào của lớp Personel thuộc nhóm crutches, sticks, wheelchairs hoặc blind không
for pedestrian in pedestrians:
    if isinstance(pedestrian, Personel):
        walkability = data['walkability']['distribution']
        if walkability.get('crutches') or walkability.get('sticks') or walkability.get('wheelchairs') or walkability.get('blind'):
            print("Có đối tượng của lớp Personel thuộc nhóm crutches, sticks, wheelchairs hoặc blind")
            break
else:
    print("Không có đối tượng của lớp Personel thuộc nhóm crutches, sticks, wheelchairs hoặc blind")
