import numpy as np

# Số lượng nhân viên y tế cần tạo
num_medical_staff = 100

# Tạo mẫu ngẫu nhiên cho tuổi của nhân viên y tế
age_medical_staff = np.random.randint(18, 70, num_medical_staff)  # Tuổi từ 18 đến 69

# Kiểm tra xem có nhân viên y tế nào có tuổi dưới 23 hoặc tuổi trên 61 không
if np.any((age_medical_staff < 23) | (age_medical_staff > 61)):
    print("Có nhân viên y tế có tuổi dưới 23 hoặc tuổi trên 61.")
else:
    print("Không có nhân viên y tế nào có tuổi dưới 23 hoặc tuổi trên 61.")
