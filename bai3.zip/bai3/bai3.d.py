import json
import random

class Pedestrian:
    def __init__(self, type):
        self.type = type
        self.journey = []

class Patient(Pedestrian):
    def __init__(self, journey):
        super().__init__('Patient')
        self.journey = journey

class Visitor(Pedestrian):
    def __init__(self, journey):
        super().__init__('Visitor')
        self.journey = journey

class Personel(Pedestrian):
    def __init__(self, journey):
        super().__init__('Personel')
        self.journey = journey

# Đọc dữ liệu từ file input.json
with open('input.json') as f:
    data = json.load(f)

# Lấy thông tin về số lượng khoa viện cần đến và danh sách các khoa viện trong tùy chọn journeyDistribution
num_of_wards = int(data['journeyDistribution']['distribution']['forPatient']['value'])
wards = [chr(i) for i in range(ord('A') + num_of_wards)]

# Tạo mảng các đối tượng Pedestrian theo số lượng yêu cầu
pedestrians = []
num_of_personel = 0

# Tính số lượng người không có khuyết tật
num_of_no_disability = data['numOfAgents']['value'] * (data['walkability']['distribution']['noDisabilityNoOvertaking']['velocity'] + data['walkability']['distribution']['noDisabilityOvertaking']['velocity'])

for _ in range(data['numOfAgents']['value']):
    journey = random.sample(wards, num_of_wards)  # Chọn ngẫu nhiên các khoa viện cần đến cho mỗi người đi bộ
    if num_of_personel < num_of_no_disability:
        pedestrians.append(Personel(journey))
        num_of_personel += 1
    elif data['walkability']['distribution']['noDisabilityNoOvertaking']['velocity']:
        pedestrians.append(Patient(journey))
    else:
        pedestrians.append(Visitor(journey))

# Kiểm tra xem số lượng phần tử trong mảng pedestrians có đúng bằng số lượng yêu cầu không
if len(pedestrians) == data['numOfAgents']['value']:
    print("Số lượng người đi bộ đã tạo đúng bằng giá trị của trường numOfAgents")
else:
    print("Số lượng người đi bộ đã tạo không đúng bằng giá trị của trường numOfAgents")

# Kiểm tra xem mỗi người đi bộ có đúng số lượng và danh sách các khoa viện cần đến không
for pedestrian in pedestrians:
    if len(pedestrian.journey) != num_of_wards:
        print("Mỗi người đi bộ không có đúng số lượng khoa viện cần đến")
    if not all(ward in pedestrian.journey for ward in wards):
        print("Một số khoa viện không xuất hiện trong danh sách các khoa viện cần đến của một số người đi bộ")
