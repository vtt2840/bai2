import numpy as np

# Số lượng người cần tạo
num_people = 1000

# Tạo mẫu ngẫu nhiên dựa trên phân phối chuẩn
# Với trung bình (mean) là 0.5 và độ lệch chuẩn (std) được tính toán sao cho tỷ lệ trong khoảng 45-55%
mean = 0.5
std = 0.5 / 1.96  # Tỉ lệ 95% nằm trong khoảng ±1.96 độ lệch chuẩn từ trung bình
personality = np.random.normal(mean, std, num_people)

# Chuẩn hóa giá trị để nằm trong khoảng từ 0 đến 1
personality = np.clip(personality, 0, 1)

# Đếm số lượng người có tính cách open hay neurotic
num_open = np.sum(personality >= 0.5)
num_neurotic = np.sum(personality < 0.5)

# In ra kết quả
print("Số lượng người có tính cách open: ", num_open)
print("Số lượng người có tính cách neurotic: ", num_neurotic)
